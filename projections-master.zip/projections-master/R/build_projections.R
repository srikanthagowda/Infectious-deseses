#' Constructor for projections objects
#'
#' This function builds a valid \code{projections} object from some input
#' simulations and dates.
#'
#' @author Thibaut Jombart \email{thibautjombart@@gmail.com}
#'
#'
#' @export
#'
#' @param x A \code{matrix} of simulated incidence stored as integers, where
#'   rows correspond to dates and columns to simulations.
#'
#' @param dates A vector of dates containing one value per row in \code{x};
#'   acceptable formats are: \code{integer}, \code{Date}, and \code{POSIXct}; if
#'   NULL, the time steps will be counted, with the first dates corresponding to
#'   0.
#'
#' @param cumulative A logical indicating if data represent cumulative
#'   incidence; defaults to \code{FALSE}.
#'
#' @param order_dates A logical indicating whether the dates should be ordered,
#'   from the oldest to the most recent one; `TRUE` by default.
#'
#'
#' @export
#'
#'
#' @seealso the \code{\link{project}} function to generate the 'projections'
#'   objects.
#'
#'
build_projections <- function(x, dates = NULL, cumulative = FALSE,
                              order_dates = TRUE) {
  out <- as.matrix(x)
  if (is.null(dates)) {
    dates <- seq_len(nrow(x)) - 1L
  }
  if (length(dates) != nrow(out)) {
    stop(
      sprintf(
        "Number of dates (%d) does not match number of rows (%d)",
        length(dates), nrow(out))
      )
  }

  ## reorder dates
  if (order_dates) {
    idx <- order(dates)
    dates <- sort(dates)
    out <- out[idx, , drop = FALSE]
  }
  
  ## shape up output
  attr(out, "dates") <- dates
  rownames(out) <- as.character(dates)
  attr(out, "cumulative") <- cumulative
  class(out) <- unique(c("projections", class(out)))
  out
}
